<?php

include 'db.php';


	$contact=$_POST['name'];
	$pass=$_POST['pass'];


// 	$contact="9328128040";
// 	$pass="1234";

	
		
	
    $sql = "SELECT * FROM register where contact = '$contact' and pass = '$pass'";
       $result = $conn->query($sql);
       if($result->num_rows > 0)
    {
        echo "Already Registered";
        
    }else
        {
                echo "Not Registered";
	
          }
        
?>
