<?php
error_reporting(E_ALL & ~ E_NOTICE);


include 'db.php';
 

while($res=mysqli_fetch_array($raw))
{
    $data[]=$res;
}
//print(json_encode($data));
echo json_encode(array("result"=>$data));
?>