<?php


$servername = "localhost";

$username = "id19544592_app2";

$password = "Admin@1234@1234";

$dbname = "id19544592_app";



$conn = new mysqli($servername,$username,$password,$dbname);
 if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
} else
{
    
}

?>