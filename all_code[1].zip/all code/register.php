<?php

include 'db.php';

	$name=$_POST['name'];
	$contact=$_POST['contact'];
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$conpass=$_POST['pass1'];

// 	$name="Vaibhav Upassani";
// 	$contact="9328128040";
// 	$email="vaibhav.upasani24@gmail.com";
// 	$pass="1234";
// 	$conpass="1234";
	
		
	
    $sql = "SELECT * FROM register where contact = '$contact'";
       $result = $conn->query($sql);
       if($result->num_rows > 0)
    {
        echo "Already Registered";
        
    }else
        {

	
			$sql="INSERT INTO `register`(`name`,`contact`,`email`,`pass`,`pass2`) VALUES ('$name','$contact','$email','$pass','$conpass')";
			if ($conn->query($sql) == true) 
				{				
					echo "User Added successfully";
				} 
				else 
				{
   					 echo "Not Added";
				}
          }
        
?>
