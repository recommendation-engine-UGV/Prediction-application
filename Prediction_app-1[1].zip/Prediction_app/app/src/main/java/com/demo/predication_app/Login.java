package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    Button login;
    TextView reg;
    RelativeLayout relativeLayout;
    EditText num,pass;
    String n,p;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        login = findViewById(R.id.login);
        reg = findViewById(R.id.reg);
        relativeLayout = findViewById(R.id.rel);
        num = findViewById(R.id.num1);
        pass = findViewById(R.id.pass1);

        Toast.makeText(this, ""+MainActivity.getcafe, Toast.LENGTH_LONG).show();
        Log.e("ch",""+MainActivity.getcafe);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              n = num.getText().toString().trim();
              p = pass.getText().toString().trim();

                progressDialog = new ProgressDialog(Login.this);
                progressDialog.setMessage("Please wait...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.setIndeterminate(false);
                progressDialog.setProgress(0);
                progressDialog.setCancelable(false);
                progressDialog.show();
                login();

            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Login.this,register.class);
                startActivity(i);


            }
        });
    }


    public void login()
    {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"login.php",
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                       if(response.contains("Not"))
                        {
                            Toast.makeText(Login.this, "Not Register", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Login.this,register.class);
                            startActivity(i);

                        }else if(response.contains("Already"))
                        {
                            Toast.makeText(Login.this, "Successfully login", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Login.this,Home.class);
                            startActivity(i);

                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Toast.makeText(this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("name",n);
                params.put("pass",p);


                return params;
            }
        };{

    };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }
}