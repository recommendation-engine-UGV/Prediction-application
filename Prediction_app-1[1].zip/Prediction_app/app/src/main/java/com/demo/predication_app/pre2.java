package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class pre2 extends AppCompatActivity {


    SwipeRefreshLayout swipeRefreshLayout;
    public static String getcafe,getapps,getmovies,getbook,gethospital;
    Context context;
    RecyclerView recycler;
    AdapterCafe adapter;
    Spinner spinner;
    Button search;
    private List<String> rest_name=new ArrayList<>();
    private List<String> rest_type=new ArrayList<>();
    private List<String> loc=new ArrayList<>();
    private List<String> dine_rating=new ArrayList<>();
    private List<String> cost=new ArrayList<>();
    private List<String> liked=new ArrayList<>();
    String location;
    private static final String[] paths = {"Select Location", "Koregaon Park", "Deccan Gymkhana", "Kalyani Nagar", "Aundh", "Viman Nagar", "Balewadi" , "Balewadi High Street, Baner" , "Baner" , "Bavdhan" , "Wakad"};
    private static final String[] paths1 = {"Select Location", "CS/Nagarpalika", "Dehuroad", "Khadki", "Aundh", "PCMC", "Pune Cantonment" , "Rural/DHO"};
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre2);




        recycler=findViewById(R.id.predict);
        Toolbar toolbar = findViewById(R.id.actiobar);
        setSupportActionBar(toolbar);

        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);


        Log.e("Apps_data2","enter inside cafe");
        try {
            JSONObject jsonObj = new JSONObject(MainActivity.getapps);
            JSONArray peoples = jsonObj.getJSONArray("result");
            Log.e("Apps_data2","enter inside cafe");

            for (int i = 0; i < peoples.length(); i++)
            {
                Log.e("Apps_data2","enter inside cafe");


                JSONObject  c = peoples.getJSONObject(i);
                Log.e("Apps_data2",""+c.getString("app_name"));
                rest_name.add(c.getString("app_name"));
                rest_type.add(c.getString("category"));
                loc.add(c.getString("size"));
                dine_rating.add(c.getString("rating"));
                cost.add(c.getString("install"));
                liked.add(c.getString("type"));


            }

            recycler.setLayoutManager(new LinearLayoutManager(this));
            adapter=new AdapterCafe(rest_name,rest_type,loc,dine_rating,cost,liked,this);
            recycler.setAdapter(adapter);
        }
        catch (Exception Ex)
        {

        }


        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                getapps();

                adapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }

        });




    }

    public void clear() {



        int size = rest_name.size();

        rest_name.clear();
        rest_type.clear();
        loc.clear();
        rest_type.clear();
        dine_rating.clear();
        cost.clear();
        liked.clear();
        adapter.notifyItemRangeRemoved(0,size);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    public void getcafe(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"cafe.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        MainActivity.getcafe = response;
                        Log.e("Cafe_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void getapps(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"apps.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        MainActivity.getapps = response;
                        Log.e("App_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }

    public void getmovies(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"movie.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        MainActivity.getmovies = response;
                        Log.e("App_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void getbook(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"book.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        MainActivity.getbook = response;
                        Log.e("App_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void gethospital(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"hosp.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        MainActivity.gethospital = response;
                        Log.e("App_data",""+response);


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }



}