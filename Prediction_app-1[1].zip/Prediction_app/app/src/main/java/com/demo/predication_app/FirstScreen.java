package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class FirstScreen extends AppCompatActivity {


        int count = 0;
        ViewPager pager;
        int[] layouts =
                {
                        R.layout.first_slide,R.layout.second_slide,R.layout.third_style
                };
        MpagerAdapter mpagerAdapter;
        LinearLayout Dots_Layout;
        ImageView[] dots;

        ImageButton bnNext;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if(new PreferenceManager(this).checkPreference())
            {
                Intent i = new Intent(FirstScreen.this,Login.class);

                startActivity(i);
                finish();
            }

            try {
                if(Build.VERSION.SDK_INT >= 19)
                {
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                }
                else
                {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                }
                setContentView(R.layout.activity_first_screen);

            }catch (Exception ae)
            {
                Toast.makeText(this, "error : "+ae, Toast.LENGTH_SHORT).show();
            }



            pager = findViewById(R.id.viewpager);
            mpagerAdapter = new MpagerAdapter(layouts,this);
            pager.setAdapter(mpagerAdapter);

            Dots_Layout = (LinearLayout) findViewById(R.id.dots_layout);
            bnNext = findViewById(R.id.bnnext);
            //bnSkip = findViewById(R.id.bnskip);

            bnNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadNextSlide();
                }
            });
        /*bnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loadHome();
                new PreferenceManager(FirstScreen.this).writePreference();

            }
        });*/
            createDots(0);

            pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {

                    createDots(position);
//                if(position==layouts.length-1)
//                {
//                    bnNext.setText("START");
//                    //bnSkip.setVisibility(View.INVISIBLE);
//                }
//                else
//                {
//                    bnNext.setText("NEXT");
//                    //bnSkip.setVisibility(View.VISIBLE);
//                }

                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });

        }

        private void createDots(int current_position)
        {
            if(Dots_Layout!=null)
            {
                Dots_Layout.removeAllViews();
                dots = new ImageView[layouts.length];

                for (int i = 0 ; i < layouts.length ; i++)
                {
                    dots[i] = new ImageView(this);
                    if(i == current_position)
                    {
                        dots[i].setImageDrawable(ContextCompat.getDrawable(this,R.drawable.active));
                    }
                    else
                    {
                        dots[i].setImageDrawable(ContextCompat.getDrawable(this,R.drawable.default_dots));
                    }
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
                    params.setMargins(4,0,4,0);

                    Dots_Layout.addView(dots[i],params);
                }
            }
        }

        private void loadHome()
        {
            Intent i = new Intent(FirstScreen.this,Login.class);

            startActivity(i);
            finish();

        }

        private void loadNextSlide()
        {
            int next_slide = pager.getCurrentItem()+1;

            if (next_slide<layouts.length)
            {
                pager.setCurrentItem(next_slide);
            }
            else {
                new PreferenceManager(this).writePreference();
                loadHome();
                finish();
            }
        }

        @Override
        protected void onResume() {
            super.onResume();
            if(new PreferenceManager(this).checkPreference())
            {
                Intent i = new Intent(FirstScreen.this,Login.class);

                startActivity(i);
                finish();
            }

        }


        @Override
        public void onBackPressed() {
            count++;
            if (count == 1) {
                finishAffinity();
                count = 0;
            }
        }
    }
