package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;
import java.util.Map;

public class register extends AppCompatActivity {

    TextView log;
    RelativeLayout relativeLayout;
    Button reg;
    Context context = this;
    String n,c,e,p,p1;
    ProgressDialog progressDialog;
    EditText name,email,num,pass,conpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        log = findViewById(R.id.log);
        reg = findViewById(R.id.reg);
        relativeLayout = findViewById(R.id.rel);

        name = findViewById(R.id.name1);
        email = findViewById(R.id.email1);
        num = findViewById(R.id.num1);
        pass = findViewById(R.id.pass1);
        conpass = findViewById(R.id.conpass1);



        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                n = name.getText().toString().trim();
                c = num.getText().toString().trim();
                e = email.getText().toString().trim();
                p = pass.getText().toString().trim();
                p1 = conpass.getText().toString().trim();

                Log.e("",""+n+c+e+p+p1);

                progressDialog = new ProgressDialog(register.this);
                progressDialog.setMessage("Please wait...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.setIndeterminate(false);
                progressDialog.setProgress(0);
                progressDialog.setCancelable(false);
                progressDialog.show();
                user();
            }
        });

        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(register.this,Login.class);
                startActivity(i);
            }
        });
    }


    public void user()
    {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"regitser.php",
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        if(response.contains("successfully"))
                        {
                            Toast.makeText(context, "Successfully Registered", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(register.this,Login.class);
                            startActivity(i);

                        }else if(response.contains("Not"))
                        {
                            Toast.makeText(context, "Facing some issue", Toast.LENGTH_SHORT).show();

                        }else if(response.contains("Already"))
                        {
                            Toast.makeText(context, "Already Registere", Toast.LENGTH_SHORT).show();

                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       // Toast.makeText(this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("name",n);
                params.put("contact",c);
                params.put("email",e);
                params.put("pass",p);
                params.put("pass1",p1);


                return params;
            }
        };{

    };


        VolleySingleton v= VolleySingleton.getInstance(context);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }
}