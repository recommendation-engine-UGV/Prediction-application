package com.demo.predication_app;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AdapterCafe extends RecyclerView.Adapter<AdapterCafe.ViewHolder> implements Filterable
{
    private List<String> rest_name;
    private List<String> rest_type;
    private List<String> loc;
    private List<String> dine_rating;
    List<String>titleAll;
    private List<String> cost;
    private List<String> liked;
    private Context context;
    LayoutInflater inflater;


    public AdapterCafe(List<String> rest_name, List<String> rest_type,List<String> loc,List<String> dine_rating,
                       List<String> cost,List<String> liked, Context context) {
        this.rest_name = rest_name;
        this.rest_type = rest_type;
        this.loc = loc;
        this.dine_rating = dine_rating;
        this.titleAll=new ArrayList<>(rest_name);
        this.inflater=LayoutInflater.from(context);
        this.cost = cost;
        this.liked = liked;
        this.context = context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= inflater.from(parent.getContext())
                .inflate(R.layout.cafecard,parent,false);


        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.rest_name.setText(rest_name.get(position));
        holder.rest_type.setText(rest_type.get(position));
        holder.loc.setText(loc.get(position));
        holder.rating.setText(dine_rating.get(position));
        holder.cost.setText(cost.get(position));
        holder.liked.setText(liked.get(position));


    }

    @Override
    public int getItemCount() {
        return rest_name.size();
    }

    @Override
    public Filter getFilter() {
        return filter;
    }
    Filter filter =new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<String>  filteredList=new ArrayList<>();

            if (charSequence.toString().isEmpty()){
                filteredList.addAll(titleAll);


            }else {
                for (String title:titleAll){
                    if(title.toLowerCase().contains(charSequence.toString().toLowerCase())){
                        filteredList.add(title);
                    }
                }



            }

            FilterResults filterResults=new FilterResults();
            filterResults.values=filteredList;


            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults filterResults) {


                rest_name.clear();
                rest_name.addAll((Collection<? extends String>) filterResults.values);


            notifyDataSetChanged();

        }
    };

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView rest_name,rest_type,loc,cost,liked,rating;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rest_name=(TextView) itemView.findViewById(R.id.rest_name);
            rest_type=(TextView) itemView.findViewById(R.id.rest_type);
            loc=(TextView) itemView.findViewById(R.id.loc);
            cost=(TextView) itemView.findViewById(R.id.cost);
            liked=(TextView) itemView.findViewById(R.id.liked);
            rating=(TextView) itemView.findViewById(R.id.rating);


        }
    }
}
