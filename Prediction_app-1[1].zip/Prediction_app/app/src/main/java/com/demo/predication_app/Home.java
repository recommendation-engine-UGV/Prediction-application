package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Home extends AppCompatActivity {
    CardView cafe,cafe1,hospital,app,movies,books;
    public static String word;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cafe =findViewById(R.id.lay1);
        cafe1 =findViewById(R.id.lay11);
        hospital =findViewById(R.id.lay3);
        app =findViewById(R.id.lay4);
        movies =findViewById(R.id.lay5);
        books =findViewById(R.id.lay6);


        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "cafe";
                Intent i = new Intent(Home.this,Predication_Activity.class);
                startActivity(i);

            }
        });
        cafe1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "cafe1";
                Intent i = new Intent(Home.this,Predication_Activity2.class);
                startActivity(i);

            }
        });

        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "Hospital";
                Intent i = new Intent(Home.this,pre5.class);
                startActivity(i);
            }
        });

        app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "apps";
                Intent i = new Intent(Home.this,pre2.class);
                startActivity(i);

            }
        });

        movies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "movies";
                Intent i = new Intent(Home.this,pre3.class);
                startActivity(i);

            }
        });

        books.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "book";
                Intent i = new Intent(Home.this,pre4.class);
                startActivity(i);

            }
        });


    }
}