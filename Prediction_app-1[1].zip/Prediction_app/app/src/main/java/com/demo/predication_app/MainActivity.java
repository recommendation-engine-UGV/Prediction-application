package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    public static String getcafe,getcafe2,getapps,getmovies,getbook,gethospital;
    Context context=this;
    ProgressDialog progressDialog;

    public static final String url = "https://recomapp.000webhostapp.com/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(context, "Dataset train process started", Toast.LENGTH_SHORT).show();

        if (checkInternet.isNetworkAvaliable(getApplicationContext()) == false)
        {
            Toast.makeText(MainActivity.this, "Check your internet", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            }, 2000);

        }else
        {

            getpy();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    getcafe();
                    getcafe2();
                    getapps();
                    getmovies();
                    getbook();
                    gethospital();                }
            }, 10000);




        }


    }


    public void getcafe(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"cafe.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getcafe = response;
                        //Log.e("Cafe_data",""+response);
                       // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }

    public void getcafe2(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"cafe_review.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getcafe2 = response;
                        Log.e("Cafe_data",""+response);
                       // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }

    public void getapps(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"apps.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getapps = response;
                        Log.e("App_data",""+response);
                       // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }

    public void getmovies(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"movie.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getmovies = response;
                        Log.e("App_data",""+response);
                       // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void getbook(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"book.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getbook = response;
                        Log.e("App_data",""+response);
                       // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void gethospital(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"hosp.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        gethospital = response;
                        Log.e("App_data",""+response);
                        //Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Intent i=new Intent(MainActivity.this,FirstScreen.class);
                                startActivity(i);
                                finish();                            }
                        }, 4000);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void getpy(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, MainActivity.url+"app.py",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(context, "Datasheet Train completed", Toast.LENGTH_SHORT).show();
                            }
                        }, 2000);


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(context, "Datasheet Train completed", Toast.LENGTH_SHORT).show();
                            }
                        }, 4000);

                        Toast.makeText(context, "Data Stored", Toast.LENGTH_SHORT).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }

}